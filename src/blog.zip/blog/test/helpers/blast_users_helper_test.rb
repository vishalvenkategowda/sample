require 'test_helper'

class BlastUsersHelperTest < ActionView::TestCase
end
