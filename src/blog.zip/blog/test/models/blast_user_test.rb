require 'test_helper'

class BlastUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
