class Rating < ActiveRecord::Base
	belongs_to :blastuser
end
