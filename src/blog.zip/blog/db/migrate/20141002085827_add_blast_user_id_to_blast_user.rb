class AddBlastUserIdToBlastUser < ActiveRecord::Migration
  def change
  end
end
