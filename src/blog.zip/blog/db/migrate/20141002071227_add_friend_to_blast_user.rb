class AddFriendToBlastUser < ActiveRecord::Migration
  def change
    #add_column :blast_users, :friend, :blast_users
  end
end
